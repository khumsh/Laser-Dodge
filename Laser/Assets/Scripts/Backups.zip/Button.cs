﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Button : MonoBehaviour {
/*
	void Update () {
		if(GameObject.FindGameObjectWithTag("GameOver").activeSelf){
			if(Input.GetKeyDown(KeyCode.R)){
				SceneManager.LoadScene("Main");
			}
		}
	} */

	public void OnClick(){

		SceneManager.LoadScene("Main");

	}

	public void Quit(){
		Application.Quit();
	}

	public void MainMenu(){
		SceneManager.LoadScene("Intro");
	}

}
